**Abstract**

This project aims to analyze the video game sales dataset available on Kaggle, provided by GregorUT. The dataset contains information on video game sales from 1980 to 2016, including the game title, platform, publisher, year of release, genre, and sales figures for different regions. The primary objective of this analysis is to gain insights into the video game industry trends, identify the most successful games, and understand the factors that contribute to their success.

We will begin by performing exploratory data analysis (EDA) to gain a better understanding of the dataset's structure and features. Then, we will use various data visualization techniques to visualize the distribution of video game sales across different regions, platforms, genres, and publishers.

The analysis will also involve building models to predict the sales figures for different regions based on various features such as platform, genre, publisher, and year of release. We will use machine learning algorithms such as linear regression, decision trees, and random forests to build these models.

The insights gained from this analysis can be useful for game developers, publishers, and marketers to make informed decisions on game development, marketing, and sales strategies. The results can also be used by gaming enthusiasts to understand the evolution of the video game industry over the past few decades.

Overall, this analysis will provide a comprehensive understanding of the video game sales dataset and its potential applications.

**pre_processing.py**

This file performs some exploratory data analysis (EDA) to understand the structure of the dataset and prepare it for modeling. 
•	Import the libraries (e.g., pandas, numpy, matplotlib).
•	Load the dataset and explore the dataset using pandas functions such as head(), describe(), and info() to understand its structure and check for missing values.
•	Drop the variables that are not needed for modeling (e.g. Critic_Count, User_Count...).
•	Split the dataset into training and testing data (80/20) using train_test_split() function from sklearn.model_selection module.

**train_model.py**

This file trains the machine learning models using the training data.
•	Using Random Forest machine learning model and sklearn library.
•	Fit the models to the training data using the fit() function.

**predict_model.py**

This file loads the models to predict the sales of video games using the testing data.
•	Use the models to predict the sales of video games using the predict() function.
•	Calculate the model accuracies, F1 score, etc. using sklearn library.
•	Print the model performance metrics.

**visualize.py**

This file creates visualizations to better understand the data and model performance. 
•	Create (grouped) bar plots, heatmaps.

**main.py**

This file calls all the previous files.
•	Call the pre_processing.py file to preprocess the data.
•	Call the train_model.py file to train the models.
•	Call the predict_model.py file to predict the sales of video games by using the testing data.
•	Call the visualize.py file to create visualizations of the data and model performance.

**Team Collaboration and Version Control**

Tianle Fu: Completed the introduction part in the ABSTRACT and provided the major codes ('pre_processing.py', 'train_model.py' and 'predict_model.py').

Yu Wu: Supplement the function of each py file in ABSTRACT, supplement 'visualize.py' and 'main.py' and integrate all source codes.

Version: April 2, 2023
