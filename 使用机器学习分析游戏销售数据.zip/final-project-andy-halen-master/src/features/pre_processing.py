from sklearn.calibration import LabelEncoder
from sklearn.model_selection import train_test_split

def pre_processing(df):
    # Drop the unrelated columns 'Critic_Count' and 'User_Count'
    df.drop(columns=['Critic_Count', 'User_Count'], inplace=True)

    # Handle the 'tbd' value and missing values 
    df.replace('tbd', float('nan'), inplace=True)
    df = df.dropna()

    # Encode categorical variables
    le = LabelEncoder()
    categorical_columns = ['Name', 'Platform', 'Genre', 'Publisher', 'Developer', 'Rating']
    for column in categorical_columns:
        df.loc[:, column] = le.fit_transform(df[column])

    # Select features & target variable
    X = df.drop(columns=['Global_Sales'])
    y_global = df['Global_Sales']

    # Split the data into training and testing sets (80/20)
    X_train, X_test, y_train, y_test = train_test_split(X, y_global, test_size=0.2, random_state=42)

    return X_train, X_test, y_train, y_test
