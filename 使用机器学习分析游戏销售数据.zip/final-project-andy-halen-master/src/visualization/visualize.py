import matplotlib.pyplot as plt
import seaborn as sns

def visualization(df):

    # Bar plot
    # Action games (most), Puzzle game (least)
    plt.figure(figsize=(12, 6))
    sns.countplot(data=df, x='Genre')
    plt.title('The Number of Games per Genre')
    plt.show()

    # Heatmap
    # For all over the world, the higher the critic score, the better the sales
    # For NA/JP/Global, they are more inclined to buy nostalgic games
    plt.figure(figsize=(12, 6))
    sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
    plt.title('The Game Sales Correlation Heatmap Among Different Regions')
    plt.show()

    # Grouped bar plot
    # Top 5: Wii Sports, GTA5, Super Mario Bros, Tetris, Mario Kart Wii
    sales_data = df.groupby("Name")["Global_Sales"].sum().sort_values(ascending=False)[:10]
    plt.bar(sales_data.index, sales_data.values)
    plt.title("Best Selling Video Games Globally")
    plt.xlabel("Game Title")
    plt.ylabel("Global Sales (millions)")
    plt.xticks(rotation=90)
    plt.show()
