import pandas as pd
from pre_processing import pre_processing
from train_model import train_model
from predict_model import predict_model
from visualize import visualization

def main():
    # Load the data that contains the worldwide video game sales from 1980 to 2016 
    df = pd.read_csv('Video_Games_Sales_as_at_22_Dec_2016.csv')
    df.head()

    # Preprocess the data
    X_train, X_test, y_train, y_test = pre_processing(df)

    # Train the model
    model = train_model(X_train, y_train)

    # Predict and evaluate
    predict_model(X_test, y_test, model)

    # Visualize the data
    visualization(df)

main()