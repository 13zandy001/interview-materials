To keep YouTube Video Presentation (non-public) follow the steps below:
- Change video privacy settings
- Sign in to YouTube Studio.
- From the left menu, select Content.
- Point to the video you'd like to update. To see your live uploads, select the Live tab.
- Click the down arrow under "Visibility" and choose `Unlisted`.
- Save and share the link below.

To watch the video presentation, click the following YouTube link:

![https://youtu.be/k9vp0Qj32AM]()
